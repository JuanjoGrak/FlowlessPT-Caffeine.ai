import { useState } from 'react';
import { useSaveCallerUserProfile } from '../hooks/useQueries';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Shield, Lock, FileCheck } from 'lucide-react';
import { Separator } from '@/components/ui/separator';

export default function ProfileSetupModal() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [preferences, setPreferences] = useState('');
  const { mutate: saveProfile, isPending } = useSaveCallerUserProfile();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim()) {
      saveProfile({ name, email, preferences });
    }
  };

  return (
    <Dialog open={true}>
      <DialogContent className="sm:max-w-md" onPointerDownOutside={(e) => e.preventDefault()}>
        <DialogHeader>
          <DialogTitle>Welcome to Flowless PT</DialogTitle>
          <DialogDescription>Please set up your profile to continue</DialogDescription>
        </DialogHeader>

        <Alert className="border-primary/50 bg-primary/5">
          <Shield className="h-4 w-4" />
          <AlertTitle className="text-sm font-semibold">Your Data is Protected</AlertTitle>
          <AlertDescription className="text-xs">
            All profile information is encrypted using AES-256 encryption and stored securely in compliance with GDPR and PCI DSS standards.
          </AlertDescription>
        </Alert>

        <div className="space-y-2 rounded-lg border bg-muted/50 p-3">
          <div className="flex items-center gap-2 text-xs font-medium">
            <Lock className="h-3 w-3" />
            <span>Security Features:</span>
          </div>
          <ul className="space-y-1 text-xs text-muted-foreground">
            <li className="flex items-center gap-2">
              <div className="h-1 w-1 rounded-full bg-primary" />
              End-to-end encryption for all data
            </li>
            <li className="flex items-center gap-2">
              <div className="h-1 w-1 rounded-full bg-primary" />
              No plain text storage
            </li>
            <li className="flex items-center gap-2">
              <div className="h-1 w-1 rounded-full bg-primary" />
              GDPR compliant data handling
            </li>
          </ul>
        </div>

        <Separator />

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Name *</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Enter your name"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="email">Email (optional)</Label>
            <Input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="your@email.com"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="preferences">Preferences (optional)</Label>
            <Textarea
              id="preferences"
              value={preferences}
              onChange={(e) => setPreferences(e.target.value)}
              placeholder="Any transport preferences or notes..."
              rows={3}
            />
          </div>

          <Button type="submit" className="w-full" disabled={isPending || !name.trim()}>
            {isPending ? 'Saving...' : 'Continue'}
          </Button>

          <p className="text-center text-xs text-muted-foreground">
            <FileCheck className="mr-1 inline h-3 w-3" />
            By continuing, you acknowledge our secure data practices
          </p>
        </form>
      </DialogContent>
    </Dialog>
  );
}
