import { useState } from 'react';
import { useGetPaymentRules, useAddPaymentRule } from '../hooks/useQueries';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Settings, Plus, Zap } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';

export default function RulesTab() {
  const { data: rules = [], isLoading } = useGetPaymentRules();
  const { mutate: addRule, isPending } = useAddPaymentRule();

  const [condition, setCondition] = useState('');
  const [action, setAction] = useState('');
  const [open, setOpen] = useState(false);

  const handleAddRule = () => {
    if (condition.trim() && action.trim()) {
      addRule(
        { condition, action },
        {
          onSuccess: () => {
            setCondition('');
            setAction('');
            setOpen(false);
          },
        }
      );
    }
  };

  return (
    <div className="space-y-6">
      {/* Info Card */}
      <Card className="border-primary/20 bg-primary/5">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Zap className="h-5 w-5" />
            Automated Payment Rules
          </CardTitle>
          <CardDescription>
            Set up conditional rules to automate your transport payments and optimize costs
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2 text-sm text-muted-foreground">
            <p>• Create rules based on conditions like time, route, or fare amount</p>
            <p>• Automate recurring payments for frequently used routes</p>
            <p>• Set spending limits and alerts for budget management</p>
          </div>
        </CardContent>
      </Card>

      {/* Add Rule */}
      <Card>
        <CardHeader>
          <CardTitle>Rule Management</CardTitle>
          <CardDescription>Create and manage your payment automation rules</CardDescription>
        </CardHeader>
        <CardContent>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Add Rule
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create Payment Rule</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="condition">Condition</Label>
                  <Input
                    id="condition"
                    value={condition}
                    onChange={(e) => setCondition(e.target.value)}
                    placeholder="e.g., If fare > 5.00"
                  />
                  <p className="text-xs text-muted-foreground">
                    Define when this rule should trigger (e.g., time, route, amount)
                  </p>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="action">Action</Label>
                  <Input
                    id="action"
                    value={action}
                    onChange={(e) => setAction(e.target.value)}
                    placeholder="e.g., Use IC tokens for payment"
                  />
                  <p className="text-xs text-muted-foreground">
                    What should happen when the condition is met
                  </p>
                </div>
                <Button onClick={handleAddRule} disabled={isPending || !condition || !action} className="w-full">
                  {isPending ? 'Creating...' : 'Create Rule'}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </CardContent>
      </Card>

      {/* Rules List */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            Active Rules
          </CardTitle>
          <CardDescription>Your configured payment automation rules</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-3">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-24 animate-pulse rounded-lg bg-muted" />
              ))}
            </div>
          ) : rules.length === 0 ? (
            <div className="py-12 text-center">
              <Settings className="mx-auto mb-4 h-12 w-12 text-muted-foreground/50" />
              <p className="text-muted-foreground">No payment rules configured yet</p>
              <p className="text-sm text-muted-foreground">Create your first rule to automate payments</p>
            </div>
          ) : (
            <ScrollArea className="h-[400px]">
              <div className="space-y-3">
                {rules
                  .slice()
                  .reverse()
                  .map((rule) => (
                    <div key={rule.id.toString()} className="rounded-lg border p-4">
                      <div className="mb-3 flex items-start justify-between">
                        <Badge variant="secondary">Active</Badge>
                      </div>
                      <div className="space-y-2">
                        <div>
                          <p className="text-xs font-medium uppercase text-muted-foreground">Condition</p>
                          <p className="font-medium">{rule.condition}</p>
                        </div>
                        <div>
                          <p className="text-xs font-medium uppercase text-muted-foreground">Action</p>
                          <p className="text-sm text-muted-foreground">{rule.action}</p>
                        </div>
                      </div>
                    </div>
                  ))}
              </div>
            </ScrollArea>
          )}
        </CardContent>
      </Card>

      {/* Example Rules */}
      <Card>
        <CardHeader>
          <CardTitle>Example Rules</CardTitle>
          <CardDescription>Get inspired by these common automation patterns</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <ExampleRule
              condition="If journey time is between 9 AM - 5 PM"
              action="Use stablecoins for payment"
            />
            <ExampleRule
              condition="If fare amount exceeds 10.00"
              action="Send notification and require manual approval"
            />
            <ExampleRule
              condition="If route contains 'Express'"
              action="Automatically approve and use IC tokens"
            />
            <ExampleRule
              condition="If daily spending exceeds 20.00"
              action="Send budget alert notification"
            />
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function ExampleRule({ condition, action }: { condition: string; action: string }) {
  return (
    <div className="rounded-lg border border-dashed p-3">
      <div className="space-y-1">
        <p className="text-sm">
          <span className="font-medium">If:</span> {condition}
        </p>
        <p className="text-sm text-muted-foreground">
          <span className="font-medium">Then:</span> {action}
        </p>
      </div>
    </div>
  );
}
