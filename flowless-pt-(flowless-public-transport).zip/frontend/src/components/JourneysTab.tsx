import { useState } from 'react';
import { useGetJourneyHistory, useAddJourney } from '../hooks/useQueries';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { MapPin, Plus, Calendar } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';

export default function JourneysTab() {
  const { data: journeys = [], isLoading } = useGetJourneyHistory();
  const { mutate: addJourney, isPending } = useAddJourney();

  const [route, setRoute] = useState('');
  const [fare, setFare] = useState('');
  const [open, setOpen] = useState(false);

  const handleAddJourney = () => {
    const fareAmount = parseFloat(fare);
    if (route.trim() && fareAmount > 0) {
      addJourney(
        { route, fare: BigInt(Math.floor(fareAmount * 100)) },
        {
          onSuccess: () => {
            setRoute('');
            setFare('');
            setOpen(false);
          },
        }
      );
    }
  };

  const formatAmount = (amount: bigint) => {
    return (Number(amount) / 100).toFixed(2);
  };

  const formatDate = (timestamp: bigint) => {
    const date = new Date(Number(timestamp) / 1000000);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
  };

  const totalSpent = journeys.reduce((sum, journey) => sum + Number(journey.fare), 0);

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid gap-6 md:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-medium">Total Journeys</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">{journeys.length}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-medium">Total Spent</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">{(totalSpent / 100).toFixed(2)}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-medium">Average Fare</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">
              {journeys.length > 0 ? (totalSpent / journeys.length / 100).toFixed(2) : '0.00'}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Add Journey */}
      <Card>
        <CardHeader>
          <CardTitle>Journey Management</CardTitle>
          <CardDescription>Track your public transport journeys</CardDescription>
        </CardHeader>
        <CardContent>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Add Journey
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add New Journey</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="route">Route</Label>
                  <Input
                    id="route"
                    value={route}
                    onChange={(e) => setRoute(e.target.value)}
                    placeholder="e.g., Victoria to Oxford Circus"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="fare">Fare Amount</Label>
                  <Input
                    id="fare"
                    type="number"
                    step="0.01"
                    min="0"
                    value={fare}
                    onChange={(e) => setFare(e.target.value)}
                    placeholder="0.00"
                  />
                </div>
                <Button onClick={handleAddJourney} disabled={isPending || !route || !fare} className="w-full">
                  {isPending ? 'Adding...' : 'Add Journey'}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </CardContent>
      </Card>

      {/* Journey History */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MapPin className="h-5 w-5" />
            Journey History
          </CardTitle>
          <CardDescription>Your recent transport journeys</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-3">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-20 animate-pulse rounded-lg bg-muted" />
              ))}
            </div>
          ) : journeys.length === 0 ? (
            <div className="py-12 text-center">
              <MapPin className="mx-auto mb-4 h-12 w-12 text-muted-foreground/50" />
              <p className="text-muted-foreground">No journeys recorded yet</p>
              <p className="text-sm text-muted-foreground">Add your first journey to start tracking</p>
            </div>
          ) : (
            <ScrollArea className="h-[400px]">
              <div className="space-y-3">
                {journeys
                  .slice()
                  .reverse()
                  .map((journey) => (
                    <div key={journey.id.toString()} className="rounded-lg border p-4">
                      <div className="mb-2 flex items-start justify-between">
                        <div className="flex-1">
                          <p className="font-semibold">{journey.route}</p>
                          <div className="mt-1 flex items-center gap-2 text-sm text-muted-foreground">
                            <Calendar className="h-3 w-3" />
                            {formatDate(journey.date)}
                          </div>
                        </div>
                        <Badge variant="secondary" className="text-base font-semibold">
                          {formatAmount(journey.fare)}
                        </Badge>
                      </div>
                    </div>
                  ))}
              </div>
            </ScrollArea>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
