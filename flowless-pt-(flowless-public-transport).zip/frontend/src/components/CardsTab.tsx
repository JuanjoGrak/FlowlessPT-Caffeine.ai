import { useState } from 'react';
import {
  useGetOysterCard,
  useLinkOysterCard,
  useGetLinkedBankCards,
  useLinkBankCard,
  useTopUpOysterCard,
  useSetAutoTopUp,
  useDisableAutoTopUp,
} from '../hooks/useQueries';
import { maskCardNumber, validateCardNumber, validateExpiryDate } from '../lib/encryption';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { CreditCard, Plus, Wallet, Shield, AlertCircle } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';

export default function CardsTab() {
  const { data: oysterCard, isLoading: oysterLoading } = useGetOysterCard();
  const { data: bankCards = [], isLoading: bankCardsLoading } = useGetLinkedBankCards();
  const { mutate: linkOyster, isPending: linkOysterPending } = useLinkOysterCard();
  const { mutate: linkBank, isPending: linkBankPending } = useLinkBankCard();
  const { mutate: topUp, isPending: topUpPending } = useTopUpOysterCard();
  const { mutate: setAutoTopUp, isPending: setAutoTopUpPending } = useSetAutoTopUp();
  const { mutate: disableAutoTopUp, isPending: disableAutoTopUpPending } = useDisableAutoTopUp();

  const [oysterNumber, setOysterNumber] = useState('');
  const [topUpAmount, setTopUpAmount] = useState('');
  const [topUpSource, setTopUpSource] = useState('balance');
  const [autoTopUpThreshold, setAutoTopUpThreshold] = useState('');
  const [autoTopUpSource, setAutoTopUpSource] = useState('balance');
  const [bankCardNumber, setBankCardNumber] = useState('');
  const [bankHolderName, setBankHolderName] = useState('');
  const [bankExpiry, setBankExpiry] = useState('');

  const [linkOysterOpen, setLinkOysterOpen] = useState(false);
  const [topUpOpen, setTopUpOpen] = useState(false);
  const [autoTopUpOpen, setAutoTopUpOpen] = useState(false);
  const [linkBankOpen, setLinkBankOpen] = useState(false);

  const [cardValidationError, setCardValidationError] = useState('');
  const [expiryValidationError, setExpiryValidationError] = useState('');

  const handleLinkOyster = () => {
    setCardValidationError('');
    
    if (oysterNumber.length < 12) {
      setCardValidationError('Card number must be at least 12 digits');
      return;
    }

    linkOyster(oysterNumber, {
      onSuccess: () => {
        setOysterNumber('');
        setLinkOysterOpen(false);
      },
    });
  };

  const handleTopUp = () => {
    const amount = parseFloat(topUpAmount);
    if (amount > 0) {
      topUp(
        { amount: BigInt(Math.floor(amount * 100)), from: topUpSource },
        {
          onSuccess: () => {
            setTopUpAmount('');
            setTopUpOpen(false);
          },
        }
      );
    }
  };

  const handleSetAutoTopUp = () => {
    const threshold = parseFloat(autoTopUpThreshold);
    if (threshold > 0) {
      setAutoTopUp(
        { threshold: BigInt(Math.floor(threshold * 100)), fundingSource: autoTopUpSource },
        {
          onSuccess: () => {
            setAutoTopUpThreshold('');
            setAutoTopUpOpen(false);
          },
        }
      );
    }
  };

  const handleDisableAutoTopUp = () => {
    disableAutoTopUp();
  };

  const handleLinkBank = () => {
    setCardValidationError('');
    setExpiryValidationError('');

    if (bankCardNumber.length < 13 || bankCardNumber.length > 19) {
      setCardValidationError('Card number must be between 13 and 19 digits');
      return;
    }

    if (!validateCardNumber(bankCardNumber)) {
      setCardValidationError('Invalid card number');
      return;
    }

    if (!validateExpiryDate(bankExpiry)) {
      setExpiryValidationError('Invalid or expired date');
      return;
    }

    if (!bankHolderName.trim()) {
      return;
    }

    linkBank(
      { cardNumber: bankCardNumber, holderName: bankHolderName, expiry: bankExpiry },
      {
        onSuccess: () => {
          setBankCardNumber('');
          setBankHolderName('');
          setBankExpiry('');
          setLinkBankOpen(false);
        },
      }
    );
  };

  const formatAmount = (amount: bigint) => {
    return (Number(amount) / 100).toFixed(2);
  };

  return (
    <div className="grid gap-6">
      {/* Security Notice */}
      <Alert className="border-primary/50 bg-primary/5">
        <Shield className="h-4 w-4" />
        <AlertDescription>
          All card data is encrypted using AES-256 encryption and stored securely. Your sensitive information is protected in compliance with PCI DSS and GDPR standards.
        </AlertDescription>
      </Alert>

      {/* Oyster Card Section */}
      <Card className="bg-gradient-to-br from-blue-500/10 to-cyan-500/10">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <CreditCard className="h-5 w-5" />
                Oyster Card
              </CardTitle>
              <CardDescription>Your linked Oyster card for London transport</CardDescription>
            </div>
            {oysterCard && (
              <img
                src="/assets/generated/oyster-card.dim_300x200.png"
                alt="Oyster Card"
                className="h-16 w-24 rounded object-cover"
              />
            )}
          </div>
        </CardHeader>
        <CardContent>
          {oysterLoading ? (
            <div className="h-32 animate-pulse rounded-lg bg-muted" />
          ) : oysterCard ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between rounded-lg border bg-card p-4">
                <div>
                  <p className="text-sm text-muted-foreground">Card Number</p>
                  <p className="font-mono text-lg font-medium">{maskCardNumber(oysterCard.cardNumber)}</p>
                  <div className="mt-1 flex items-center gap-1 text-xs text-muted-foreground">
                    <Shield className="h-3 w-3" />
                    <span>Encrypted</span>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm text-muted-foreground">Balance</p>
                  <p className="text-2xl font-bold">£{formatAmount(oysterCard.balance)}</p>
                </div>
              </div>

              {oysterCard.autoTopUp && (
                <div className="rounded-lg border bg-accent/10 p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Auto Top-Up Enabled</p>
                      <p className="text-sm text-muted-foreground">
                        Threshold: £{formatAmount(oysterCard.threshold)} • Source: {oysterCard.fundingSource}
                      </p>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleDisableAutoTopUp}
                      disabled={disableAutoTopUpPending}
                    >
                      {disableAutoTopUpPending ? 'Disabling...' : 'Disable'}
                    </Button>
                  </div>
                </div>
              )}

              <div className="flex flex-wrap gap-2">
                <Dialog open={topUpOpen} onOpenChange={setTopUpOpen}>
                  <DialogTrigger asChild>
                    <Button>
                      <Wallet className="mr-2 h-4 w-4" />
                      Top Up
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Top Up Oyster Card</DialogTitle>
                      <DialogDescription>Add funds to your Oyster card balance</DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="topup-amount">Amount (£)</Label>
                        <Input
                          id="topup-amount"
                          type="number"
                          step="0.01"
                          min="0"
                          value={topUpAmount}
                          onChange={(e) => setTopUpAmount(e.target.value)}
                          placeholder="10.00"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="topup-source">Funding Source</Label>
                        <Select value={topUpSource} onValueChange={setTopUpSource}>
                          <SelectTrigger id="topup-source">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="balance">Wallet Balance</SelectItem>
                            <SelectItem value="bank-card">Bank Card</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <Button onClick={handleTopUp} disabled={topUpPending || !topUpAmount} className="w-full">
                        {topUpPending ? 'Processing...' : 'Confirm Top Up'}
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>

                {!oysterCard.autoTopUp && (
                  <Dialog open={autoTopUpOpen} onOpenChange={setAutoTopUpOpen}>
                    <DialogTrigger asChild>
                      <Button variant="outline">Enable Auto Top-Up</Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Enable Auto Top-Up</DialogTitle>
                        <DialogDescription>Automatically top up when balance is low</DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div className="space-y-2">
                          <Label htmlFor="auto-threshold">Threshold (£)</Label>
                          <Input
                            id="auto-threshold"
                            type="number"
                            step="0.01"
                            min="0"
                            value={autoTopUpThreshold}
                            onChange={(e) => setAutoTopUpThreshold(e.target.value)}
                            placeholder="5.00"
                          />
                          <p className="text-xs text-muted-foreground">
                            Auto top-up will trigger when balance falls below this amount
                          </p>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="auto-source">Funding Source</Label>
                          <Select value={autoTopUpSource} onValueChange={setAutoTopUpSource}>
                            <SelectTrigger id="auto-source">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="balance">Wallet Balance</SelectItem>
                              <SelectItem value="bank-card">Bank Card</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <Button
                          onClick={handleSetAutoTopUp}
                          disabled={setAutoTopUpPending || !autoTopUpThreshold}
                          className="w-full"
                        >
                          {setAutoTopUpPending ? 'Enabling...' : 'Enable Auto Top-Up'}
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>
                )}
              </div>
            </div>
          ) : (
            <div className="space-y-4 text-center">
              <p className="text-muted-foreground">No Oyster card linked yet</p>
              <Dialog open={linkOysterOpen} onOpenChange={setLinkOysterOpen}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="mr-2 h-4 w-4" />
                    Link Oyster Card
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Link Oyster Card</DialogTitle>
                    <DialogDescription>
                      Your card details will be encrypted and stored securely
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <Alert className="border-primary/50 bg-primary/5">
                      <Shield className="h-4 w-4" />
                      <AlertDescription className="text-xs">
                        All card data is encrypted using AES-256 before storage
                      </AlertDescription>
                    </Alert>
                    <div className="space-y-2">
                      <Label htmlFor="oyster-number">Card Number</Label>
                      <Input
                        id="oyster-number"
                        type="text"
                        maxLength={16}
                        value={oysterNumber}
                        onChange={(e) => {
                          setOysterNumber(e.target.value.replace(/\D/g, ''));
                          setCardValidationError('');
                        }}
                        placeholder="1234567890123456"
                      />
                      {cardValidationError && (
                        <div className="flex items-center gap-1 text-xs text-destructive">
                          <AlertCircle className="h-3 w-3" />
                          <span>{cardValidationError}</span>
                        </div>
                      )}
                      <p className="text-xs text-muted-foreground">Enter your 12-16 digit Oyster card number</p>
                    </div>
                    <Button
                      onClick={handleLinkOyster}
                      disabled={linkOysterPending || oysterNumber.length < 12}
                      className="w-full"
                    >
                      {linkOysterPending ? 'Linking...' : 'Link Card'}
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Bank Cards Section */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <CreditCard className="h-5 w-5" />
                Bank Cards
              </CardTitle>
              <CardDescription>Manage your linked bank cards for payments</CardDescription>
            </div>
            <Dialog open={linkBankOpen} onOpenChange={setLinkBankOpen}>
              <DialogTrigger asChild>
                <Button size="sm">
                  <Plus className="mr-2 h-4 w-4" />
                  Add Card
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Link Bank Card</DialogTitle>
                  <DialogDescription>
                    Your card details will be encrypted and stored securely
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <Alert className="border-primary/50 bg-primary/5">
                    <Shield className="h-4 w-4" />
                    <AlertDescription className="text-xs">
                      PCI DSS compliant - All card data is encrypted using AES-256
                    </AlertDescription>
                  </Alert>
                  <div className="space-y-2">
                    <Label htmlFor="bank-number">Card Number</Label>
                    <Input
                      id="bank-number"
                      type="text"
                      maxLength={19}
                      value={bankCardNumber}
                      onChange={(e) => {
                        setBankCardNumber(e.target.value.replace(/\D/g, ''));
                        setCardValidationError('');
                      }}
                      placeholder="1234567890123456"
                    />
                    {cardValidationError && (
                      <div className="flex items-center gap-1 text-xs text-destructive">
                        <AlertCircle className="h-3 w-3" />
                        <span>{cardValidationError}</span>
                      </div>
                    )}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="bank-holder">Cardholder Name</Label>
                    <Input
                      id="bank-holder"
                      type="text"
                      value={bankHolderName}
                      onChange={(e) => setBankHolderName(e.target.value)}
                      placeholder="John Doe"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="bank-expiry">Expiry Date</Label>
                    <Input
                      id="bank-expiry"
                      type="text"
                      maxLength={5}
                      value={bankExpiry}
                      onChange={(e) => {
                        let value = e.target.value.replace(/\D/g, '');
                        if (value.length >= 2) {
                          value = value.slice(0, 2) + '/' + value.slice(2, 4);
                        }
                        setBankExpiry(value);
                        setExpiryValidationError('');
                      }}
                      placeholder="MM/YY"
                    />
                    {expiryValidationError && (
                      <div className="flex items-center gap-1 text-xs text-destructive">
                        <AlertCircle className="h-3 w-3" />
                        <span>{expiryValidationError}</span>
                      </div>
                    )}
                  </div>
                  <Button
                    onClick={handleLinkBank}
                    disabled={linkBankPending || bankCardNumber.length < 13 || !bankHolderName || !bankExpiry}
                    className="w-full"
                  >
                    {linkBankPending ? 'Linking...' : 'Link Card'}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          {bankCardsLoading ? (
            <div className="space-y-3">
              {[1, 2].map((i) => (
                <div key={i} className="h-24 animate-pulse rounded-lg bg-muted" />
              ))}
            </div>
          ) : bankCards.length === 0 ? (
            <p className="py-8 text-center text-muted-foreground">No bank cards linked yet</p>
          ) : (
            <div className="space-y-3">
              {bankCards.map((card, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between rounded-lg border bg-gradient-to-r from-slate-800 to-slate-900 p-4 text-white"
                >
                  <div className="flex items-center gap-4">
                    <img
                      src="/assets/generated/bank-card-template.dim_300x200.png"
                      alt="Bank Card"
                      className="h-12 w-16 rounded object-cover opacity-50"
                    />
                    <div>
                      <p className="font-mono text-sm">{maskCardNumber(card.cardNumber)}</p>
                      <p className="text-xs text-slate-300">{card.holderName}</p>
                      <div className="mt-1 flex items-center gap-1 text-xs text-slate-400">
                        <Shield className="h-3 w-3" />
                        <span>Encrypted</span>
                      </div>
                    </div>
                  </div>
                  <Badge variant="outline" className="border-white/20 text-white">
                    {card.expiry}
                  </Badge>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
