import { Button } from '@/components/ui/button';
import { useInternetIdentity } from '../hooks/useInternetIdentity';
import { Wallet, Shield, Zap, TrendingUp } from 'lucide-react';

export default function LoginPrompt() {
  const { login, loginStatus } = useInternetIdentity();

  return (
    <div className="relative overflow-hidden">
      {/* Hero Section */}
      <section className="container relative py-20 md:py-32">
        <div className="absolute inset-0 -z-10 bg-gradient-to-br from-primary/5 via-accent/5 to-background" />
        
        <div className="mx-auto max-w-4xl text-center">
          <div className="mb-8 inline-flex items-center justify-center">
            <img
              src="/assets/generated/hero-banner.dim_1200x600.png"
              alt="Flowless PT Transport Wallet"
              className="h-48 w-auto rounded-2xl shadow-2xl"
            />
          </div>

          <h1 className="mb-6 text-4xl font-bold tracking-tight sm:text-5xl md:text-6xl">
            Decentralized Public
            <br />
            <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              Transport Wallet
            </span>
          </h1>

          <p className="mb-10 text-lg text-muted-foreground md:text-xl">
            Manage your transport payments with blockchain security. Track journeys, automate fares, and optimize
            costs with DeFi analytics.
          </p>

          <Button
            size="lg"
            onClick={login}
            disabled={loginStatus === 'logging-in'}
            className="h-12 px-8 text-base font-semibold"
          >
            {loginStatus === 'logging-in' ? 'Connecting...' : 'Get Started'}
          </Button>
        </div>
      </section>

      {/* Features Section */}
      <section className="container py-20">
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
          <FeatureCard
            icon={<Wallet className="h-8 w-8" />}
            title="Secure Vault"
            description="Store IC tokens and stablecoins with blockchain-level security"
          />
          <FeatureCard
            icon={<Zap className="h-8 w-8" />}
            title="Auto Payments"
            description="Automated fare payments with batch processing for efficiency"
          />
          <FeatureCard
            icon={<TrendingUp className="h-8 w-8" />}
            title="DeFi Analytics"
            description="Track spending patterns and optimize transport costs"
          />
          <FeatureCard
            icon={<Shield className="h-8 w-8" />}
            title="Smart Rules"
            description="Set conditional payments and spending limits"
          />
        </div>
      </section>

      {/* How It Works */}
      <section className="container py-20">
        <div className="mx-auto max-w-3xl">
          <h2 className="mb-12 text-center text-3xl font-bold tracking-tight">How It Works</h2>
          
          <div className="space-y-8">
            <Step
              number="1"
              title="Connect Your Identity"
              description="Securely login with Internet Identity for decentralized authentication"
            />
            <Step
              number="2"
              title="Deposit Funds"
              description="Add IC tokens or stablecoins to your secure vault"
            />
            <Step
              number="3"
              title="Travel & Track"
              description="Use public transport and automatically track your journeys"
            />
            <Step
              number="4"
              title="Optimize & Save"
              description="Review analytics and optimize your transport spending"
            />
          </div>
        </div>
      </section>
    </div>
  );
}

function FeatureCard({ icon, title, description }: { icon: React.ReactNode; title: string; description: string }) {
  return (
    <div className="group relative overflow-hidden rounded-2xl border border-border bg-card p-6 transition-all hover:shadow-lg">
      <div className="mb-4 inline-flex h-14 w-14 items-center justify-center rounded-xl bg-primary/10 text-primary transition-colors group-hover:bg-primary group-hover:text-primary-foreground">
        {icon}
      </div>
      <h3 className="mb-2 text-lg font-semibold">{title}</h3>
      <p className="text-sm text-muted-foreground">{description}</p>
    </div>
  );
}

function Step({ number, title, description }: { number: string; title: string; description: string }) {
  return (
    <div className="flex gap-6">
      <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-primary text-lg font-bold text-primary-foreground">
        {number}
      </div>
      <div className="pt-1">
        <h3 className="mb-2 text-xl font-semibold">{title}</h3>
        <p className="text-muted-foreground">{description}</p>
      </div>
    </div>
  );
}

