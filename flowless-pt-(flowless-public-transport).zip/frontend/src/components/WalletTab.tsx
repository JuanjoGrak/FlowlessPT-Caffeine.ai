import { useState } from 'react';
import { useGetBalance, useDeposit, useWithdraw, useGetTransactionHistory } from '../hooks/useQueries';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Wallet, ArrowDownToLine, ArrowUpFromLine, Clock, Shield } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';

export default function WalletTab() {
  const { data: balance, isLoading: balanceLoading } = useGetBalance();
  const { data: transactions = [], isLoading: transactionsLoading } = useGetTransactionHistory();
  const { mutate: deposit, isPending: depositPending } = useDeposit();
  const { mutate: withdraw, isPending: withdrawPending } = useWithdraw();

  const [depositAmount, setDepositAmount] = useState('');
  const [depositCurrency, setDepositCurrency] = useState('IC');
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [withdrawCurrency, setWithdrawCurrency] = useState('IC');
  const [depositOpen, setDepositOpen] = useState(false);
  const [withdrawOpen, setWithdrawOpen] = useState(false);

  const handleDeposit = () => {
    const amount = parseFloat(depositAmount);
    if (amount > 0) {
      deposit(
        { amount: BigInt(Math.floor(amount * 100)), currency: depositCurrency },
        {
          onSuccess: () => {
            setDepositAmount('');
            setDepositOpen(false);
          },
        }
      );
    }
  };

  const handleWithdraw = () => {
    const amount = parseFloat(withdrawAmount);
    if (amount > 0) {
      withdraw(
        { amount: BigInt(Math.floor(amount * 100)), currency: withdrawCurrency },
        {
          onSuccess: () => {
            setWithdrawAmount('');
            setWithdrawOpen(false);
          },
        }
      );
    }
  };

  const formatAmount = (amount: bigint) => {
    return (Number(amount) / 100).toFixed(2);
  };

  const formatDate = (timestamp: bigint) => {
    const date = new Date(Number(timestamp) / 1000000);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
  };

  return (
    <div className="grid gap-6 md:grid-cols-2">
      {/* Balance Cards */}
      <Card className="bg-gradient-to-br from-primary/10 to-accent/10">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Wallet className="h-5 w-5" />
            IC Tokens
          </CardTitle>
          <CardDescription>Internet Computer tokens</CardDescription>
        </CardHeader>
        <CardContent>
          {balanceLoading ? (
            <div className="h-12 w-32 animate-pulse rounded bg-muted" />
          ) : (
            <div>
              <p className="text-4xl font-bold">{formatAmount(balance?.icTokens || BigInt(0))}</p>
              <div className="mt-2 flex items-center gap-1 text-xs text-muted-foreground">
                <Shield className="h-3 w-3" />
                <span>Encrypted balance</span>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="bg-gradient-to-br from-accent/10 to-primary/10">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Wallet className="h-5 w-5" />
            Stablecoins
          </CardTitle>
          <CardDescription>Stable currency balance</CardDescription>
        </CardHeader>
        <CardContent>
          {balanceLoading ? (
            <div className="h-12 w-32 animate-pulse rounded bg-muted" />
          ) : (
            <div>
              <p className="text-4xl font-bold">{formatAmount(balance?.stablecoins || BigInt(0))}</p>
              <div className="mt-2 flex items-center gap-1 text-xs text-muted-foreground">
                <Shield className="h-3 w-3" />
                <span>Encrypted balance</span>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Actions */}
      <Card className="md:col-span-2">
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
          <CardDescription>Deposit or withdraw funds from your wallet</CardDescription>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-4">
          <Dialog open={depositOpen} onOpenChange={setDepositOpen}>
            <DialogTrigger asChild>
              <Button className="flex-1 sm:flex-none">
                <ArrowDownToLine className="mr-2 h-4 w-4" />
                Deposit
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Deposit Funds</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="deposit-amount">Amount</Label>
                  <Input
                    id="deposit-amount"
                    type="number"
                    step="0.01"
                    min="0"
                    value={depositAmount}
                    onChange={(e) => setDepositAmount(e.target.value)}
                    placeholder="0.00"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="deposit-currency">Currency</Label>
                  <Select value={depositCurrency} onValueChange={setDepositCurrency}>
                    <SelectTrigger id="deposit-currency">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="IC">IC Tokens</SelectItem>
                      <SelectItem value="Stable">Stablecoins</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Button onClick={handleDeposit} disabled={depositPending || !depositAmount} className="w-full">
                  {depositPending ? 'Processing...' : 'Confirm Deposit'}
                </Button>
              </div>
            </DialogContent>
          </Dialog>

          <Dialog open={withdrawOpen} onOpenChange={setWithdrawOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" className="flex-1 sm:flex-none">
                <ArrowUpFromLine className="mr-2 h-4 w-4" />
                Withdraw
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Withdraw Funds</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="withdraw-amount">Amount</Label>
                  <Input
                    id="withdraw-amount"
                    type="number"
                    step="0.01"
                    min="0"
                    value={withdrawAmount}
                    onChange={(e) => setWithdrawAmount(e.target.value)}
                    placeholder="0.00"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="withdraw-currency">Currency</Label>
                  <Select value={withdrawCurrency} onValueChange={setWithdrawCurrency}>
                    <SelectTrigger id="withdraw-currency">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="IC">IC Tokens</SelectItem>
                      <SelectItem value="Stable">Stablecoins</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Button onClick={handleWithdraw} disabled={withdrawPending || !withdrawAmount} className="w-full">
                  {withdrawPending ? 'Processing...' : 'Confirm Withdrawal'}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </CardContent>
      </Card>

      {/* Transaction History */}
      <Card className="md:col-span-2">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                Transaction History
              </CardTitle>
              <CardDescription>Recent deposits and withdrawals</CardDescription>
            </div>
            <Badge variant="outline" className="border-primary/50 text-primary">
              <Shield className="mr-1 h-3 w-3" />
              Encrypted
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          {transactionsLoading ? (
            <div className="space-y-3">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-16 animate-pulse rounded-lg bg-muted" />
              ))}
            </div>
          ) : transactions.length === 0 ? (
            <p className="py-8 text-center text-muted-foreground">No transactions yet</p>
          ) : (
            <ScrollArea className="h-[300px]">
              <div className="space-y-3">
                {transactions
                  .slice()
                  .reverse()
                  .map((tx) => (
                    <div key={tx.id.toString()} className="flex items-center justify-between rounded-lg border p-4">
                      <div>
                        <p className="font-medium">{tx.description}</p>
                        <p className="text-sm text-muted-foreground">{formatDate(tx.timestamp)}</p>
                      </div>
                      <p className="text-lg font-semibold">{formatAmount(tx.amount)}</p>
                    </div>
                  ))}
              </div>
            </ScrollArea>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
