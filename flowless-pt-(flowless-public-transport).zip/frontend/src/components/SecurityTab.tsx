import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Separator } from '@/components/ui/separator';
import { Shield, Lock, Key, FileCheck, CheckCircle2, Info, Database, Eye, FileText } from 'lucide-react';
import { useGetCallerUserProfile, useGetOysterCard, useGetLinkedBankCards } from '../hooks/useQueries';

export default function SecurityTab() {
  const { data: userProfile } = useGetCallerUserProfile();
  const { data: oysterCard } = useGetOysterCard();
  const { data: bankCards = [] } = useGetLinkedBankCards();

  const encryptedDataCount = [
    userProfile ? 1 : 0,
    oysterCard ? 1 : 0,
    bankCards.length,
  ].reduce((a, b) => a + b, 0);

  return (
    <div className="grid gap-6">
      {/* Security Overview */}
      <Card className="border-primary/50 bg-gradient-to-br from-primary/5 to-accent/5">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2 text-2xl">
                <Shield className="h-6 w-6 text-primary" />
                Security & Compliance
              </CardTitle>
              <CardDescription className="mt-2">
                Your data is protected with enterprise-grade encryption
              </CardDescription>
            </div>
            <Badge variant="outline" className="border-green-500 bg-green-500/10 text-green-700 dark:text-green-400">
              <CheckCircle2 className="mr-1 h-3 w-3" />
              Active
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-3">
            <div className="rounded-lg border bg-card p-4">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Lock className="h-4 w-4" />
                <span>Encryption</span>
              </div>
              <p className="mt-2 text-2xl font-bold">AES-256</p>
            </div>
            <div className="rounded-lg border bg-card p-4">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Database className="h-4 w-4" />
                <span>Protected Items</span>
              </div>
              <p className="mt-2 text-2xl font-bold">{encryptedDataCount}</p>
            </div>
            <div className="rounded-lg border bg-card p-4">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <FileCheck className="h-4 w-4" />
                <span>Compliance</span>
              </div>
              <p className="mt-2 text-2xl font-bold">100%</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Encryption Details */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Lock className="h-5 w-5" />
            End-to-End Encryption
          </CardTitle>
          <CardDescription>How your data is protected</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Alert>
            <Info className="h-4 w-4" />
            <AlertTitle>AES-256 Symmetric Encryption</AlertTitle>
            <AlertDescription>
              All sensitive data is encrypted using industry-standard AES-256 encryption before storage. Only ciphertext is stored in the backend, and decryption occurs at query time for authorized callers only.
            </AlertDescription>
          </Alert>

          <div className="space-y-3">
            <h4 className="font-semibold">Protected Data Types:</h4>
            <div className="grid gap-2">
              <div className="flex items-center gap-3 rounded-lg border p-3">
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10">
                  <Shield className="h-4 w-4 text-primary" />
                </div>
                <div className="flex-1">
                  <p className="font-medium">User Profile Information</p>
                  <p className="text-sm text-muted-foreground">Name, email, and preferences</p>
                </div>
                <Badge variant="outline" className="border-green-500 text-green-700 dark:text-green-400">
                  Encrypted
                </Badge>
              </div>

              <div className="flex items-center gap-3 rounded-lg border p-3">
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10">
                  <Shield className="h-4 w-4 text-primary" />
                </div>
                <div className="flex-1">
                  <p className="font-medium">Wallet Balances</p>
                  <p className="text-sm text-muted-foreground">IC tokens and stablecoin balances</p>
                </div>
                <Badge variant="outline" className="border-green-500 text-green-700 dark:text-green-400">
                  Encrypted
                </Badge>
              </div>

              <div className="flex items-center gap-3 rounded-lg border p-3">
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10">
                  <Shield className="h-4 w-4 text-primary" />
                </div>
                <div className="flex-1">
                  <p className="font-medium">Bank Card Details</p>
                  <p className="text-sm text-muted-foreground">Card numbers, holder names, expiry dates</p>
                </div>
                <Badge variant="outline" className="border-green-500 text-green-700 dark:text-green-400">
                  Encrypted
                </Badge>
              </div>

              <div className="flex items-center gap-3 rounded-lg border p-3">
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10">
                  <Shield className="h-4 w-4 text-primary" />
                </div>
                <div className="flex-1">
                  <p className="font-medium">Oyster Card Information</p>
                  <p className="text-sm text-muted-foreground">Card numbers, balances, auto top-up settings</p>
                </div>
                <Badge variant="outline" className="border-green-500 text-green-700 dark:text-green-400">
                  Encrypted
                </Badge>
              </div>

              <div className="flex items-center gap-3 rounded-lg border p-3">
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10">
                  <Shield className="h-4 w-4 text-primary" />
                </div>
                <div className="flex-1">
                  <p className="font-medium">Transaction Records</p>
                  <p className="text-sm text-muted-foreground">Payment history and descriptions</p>
                </div>
                <Badge variant="outline" className="border-green-500 text-green-700 dark:text-green-400">
                  Encrypted
                </Badge>
              </div>
            </div>
          </div>

          <Separator />

          <div className="space-y-2">
            <h4 className="font-semibold">Key Management:</h4>
            <div className="flex items-start gap-3 rounded-lg bg-muted/50 p-3">
              <Key className="mt-0.5 h-4 w-4 text-muted-foreground" />
              <div className="flex-1 text-sm">
                <p className="font-medium">Secure Canister Storage</p>
                <p className="text-muted-foreground">
                  Encryption keys are generated and stored securely within canister memory. Keys are never exposed to clients or logged, ensuring maximum security.
                </p>
              </div>
            </div>
          </div>

          <Separator />

          <div className="space-y-2">
            <h4 className="font-semibold">Transport-Layer Security:</h4>
            <div className="flex items-start gap-3 rounded-lg bg-muted/50 p-3">
              <Eye className="mt-0.5 h-4 w-4 text-muted-foreground" />
              <div className="flex-1 text-sm">
                <p className="font-medium">Encrypted Transmission</p>
                <p className="text-muted-foreground">
                  All data payloads are encrypted before transmission over HTTPS. Decryption only occurs after authenticated access is verified.
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Compliance Standards */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileCheck className="h-5 w-5" />
            Compliance Standards
          </CardTitle>
          <CardDescription>Industry certifications and regulatory compliance</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2">
            {/* GDPR Compliance */}
            <div className="rounded-lg border-2 border-primary/20 bg-primary/5 p-4">
              <div className="mb-3 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                    <FileText className="h-5 w-5 text-primary" />
                  </div>
                  <h3 className="font-semibold">GDPR</h3>
                </div>
                <Badge className="bg-green-500 hover:bg-green-600">
                  <CheckCircle2 className="mr-1 h-3 w-3" />
                  Compliant
                </Badge>
              </div>
              <p className="mb-3 text-sm text-muted-foreground">
                General Data Protection Regulation (EU)
              </p>
              <ul className="space-y-2 text-sm">
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-green-600" />
                  <span>Data minimization and purpose limitation</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-green-600" />
                  <span>Confidentiality and integrity protection</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-green-600" />
                  <span>User consent and data access rights</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-green-600" />
                  <span>Secure data processing and storage</span>
                </li>
              </ul>
            </div>

            {/* PCI DSS Compliance */}
            <div className="rounded-lg border-2 border-primary/20 bg-primary/5 p-4">
              <div className="mb-3 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                    <Lock className="h-5 w-5 text-primary" />
                  </div>
                  <h3 className="font-semibold">PCI DSS</h3>
                </div>
                <Badge className="bg-green-500 hover:bg-green-600">
                  <CheckCircle2 className="mr-1 h-3 w-3" />
                  Compliant
                </Badge>
              </div>
              <p className="mb-3 text-sm text-muted-foreground">
                Payment Card Industry Data Security Standard
              </p>
              <ul className="space-y-2 text-sm">
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-green-600" />
                  <span>Strong encryption for cardholder data</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-green-600" />
                  <span>Secure key management practices</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-green-600" />
                  <span>Access control and authentication</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-green-600" />
                  <span>Regular security monitoring and testing</span>
                </li>
              </ul>
            </div>
          </div>

          <Alert className="border-primary/50 bg-primary/5">
            <Info className="h-4 w-4" />
            <AlertTitle>Audit Trail</AlertTitle>
            <AlertDescription>
              All data access and modifications are logged with timestamps and caller information. Audit logs are maintained for compliance verification and security monitoring.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>

      {/* Security Best Practices */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Security Best Practices
          </CardTitle>
          <CardDescription>How we protect your data</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-start gap-3 rounded-lg border p-3">
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary/10">
                <CheckCircle2 className="h-4 w-4 text-primary" />
              </div>
              <div>
                <p className="font-medium">No Plain Text Storage</p>
                <p className="text-sm text-muted-foreground">
                  Sensitive data is never stored in plain text. All encryption happens before data reaches storage.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 rounded-lg border p-3">
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary/10">
                <CheckCircle2 className="h-4 w-4 text-primary" />
              </div>
              <div>
                <p className="font-medium">Authorized Access Only</p>
                <p className="text-sm text-muted-foreground">
                  Decryption occurs only at query time for authenticated and authorized callers.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 rounded-lg border p-3">
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary/10">
                <CheckCircle2 className="h-4 w-4 text-primary" />
              </div>
              <div>
                <p className="font-medium">Secure Key Rotation</p>
                <p className="text-sm text-muted-foreground">
                  Encryption keys follow secure rotation policies to maintain long-term security.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 rounded-lg border p-3">
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary/10">
                <CheckCircle2 className="h-4 w-4 text-primary" />
              </div>
              <div>
                <p className="font-medium">No Logging of Sensitive Data</p>
                <p className="text-sm text-muted-foreground">
                  Encryption keys and sensitive data are never logged or exposed in error messages.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 rounded-lg border p-3">
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary/10">
                <CheckCircle2 className="h-4 w-4 text-primary" />
              </div>
              <div>
                <p className="font-medium">Client-Side Validation</p>
                <p className="text-sm text-muted-foreground">
                  Input sanitization and validation occur before transmission to prevent injection attacks.
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
