import { useMemo } from 'react';
import { useGetJourneyHistory, useGetTransactionHistory } from '../hooks/useQueries';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { TrendingUp, Calendar, Route, Lightbulb } from 'lucide-react';

export default function AnalyticsTab() {
  const { data: journeys = [], isLoading: journeysLoading } = useGetJourneyHistory();
  const { data: transactions = [], isLoading: transactionsLoading } = useGetTransactionHistory();

  const analytics = useMemo(() => {
    const totalSpent = journeys.reduce((sum, j) => sum + Number(j.fare), 0);
    const oysterTopUps = transactions.filter((t) => t.description.includes('Oyster card top-up'));
    const totalTopUps = oysterTopUps.reduce((sum, t) => sum + Number(t.amount), 0);
    const avgFare = journeys.length > 0 ? totalSpent / journeys.length : 0;

    // Monthly spending
    const monthlyData: { [key: string]: number } = {};
    journeys.forEach((j) => {
      const date = new Date(Number(j.date) / 1000000);
      const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
      monthlyData[monthKey] = (monthlyData[monthKey] || 0) + Number(j.fare);
    });

    // Add Oyster top-ups to monthly data
    oysterTopUps.forEach((t) => {
      const date = new Date(Number(t.timestamp) / 1000000);
      const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
      monthlyData[monthKey] = (monthlyData[monthKey] || 0) + Number(t.amount);
    });

    const monthlyChartData = Object.entries(monthlyData)
      .sort()
      .slice(-6)
      .map(([month, amount]) => ({
        month: new Date(month + '-01').toLocaleDateString('en-US', { month: 'short', year: '2-digit' }),
        amount: amount / 100,
      }));

    // Route distribution
    const routeData: { [key: string]: number } = {};
    journeys.forEach((j) => {
      routeData[j.route] = (routeData[j.route] || 0) + Number(j.fare);
    });

    const routeChartData = Object.entries(routeData)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([route, amount]) => ({
        route,
        amount: amount / 100,
      }));

    return {
      totalSpent: totalSpent / 100,
      totalTopUps: totalTopUps / 100,
      avgFare: avgFare / 100,
      journeyCount: journeys.length,
      topUpCount: oysterTopUps.length,
      monthlyChartData,
      routeChartData,
    };
  }, [journeys, transactions]);

  const COLORS = ['oklch(0.65 0.15 260)', 'oklch(0.70 0.15 180)', 'oklch(0.60 0.12 220)', 'oklch(0.75 0.10 200)', 'oklch(0.55 0.08 240)'];

  const insights = useMemo(() => {
    const tips: string[] = [];
    if (analytics.avgFare > 5) {
      tips.push('Consider using off-peak travel to save on fares');
    }
    if (analytics.journeyCount > 20) {
      tips.push('You might benefit from a monthly travel pass');
    }
    if (analytics.topUpCount > 5) {
      tips.push('Enable auto top-up to avoid running out of balance');
    }
    if (analytics.routeChartData.length > 0) {
      tips.push(`Your most used route is ${analytics.routeChartData[0].route}`);
    }
    return tips;
  }, [analytics]);

  if (journeysLoading || transactionsLoading) {
    return (
      <div className="grid gap-6">
        {[1, 2, 3].map((i) => (
          <div key={i} className="h-64 animate-pulse rounded-lg bg-muted" />
        ))}
      </div>
    );
  }

  return (
    <div className="grid gap-6">
      {/* Summary Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Spent</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">£{analytics.totalSpent.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">On journeys</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Oyster Top-Ups</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">£{analytics.totalTopUps.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">{analytics.topUpCount} top-ups</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Average Fare</CardTitle>
            <Route className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">£{analytics.avgFare.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">Per journey</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Journeys</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{analytics.journeyCount}</div>
            <p className="text-xs text-muted-foreground">Recorded trips</p>
          </CardContent>
        </Card>
      </div>

      {/* Monthly Spending Chart */}
      <Card>
        <CardHeader>
          <CardTitle>Monthly Spending</CardTitle>
          <CardDescription>Transport expenses and Oyster top-ups over the last 6 months</CardDescription>
        </CardHeader>
        <CardContent>
          {analytics.monthlyChartData.length === 0 ? (
            <p className="py-8 text-center text-muted-foreground">No data available yet</p>
          ) : (
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={analytics.monthlyChartData}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis dataKey="month" className="text-xs" />
                <YAxis className="text-xs" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px',
                  }}
                  formatter={(value: number) => [`£${value.toFixed(2)}`, 'Amount']}
                />
                <Bar dataKey="amount" fill="oklch(0.65 0.15 260)" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </CardContent>
      </Card>

      {/* Route Distribution */}
      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Top Routes</CardTitle>
            <CardDescription>Your most frequently used routes</CardDescription>
          </CardHeader>
          <CardContent>
            {analytics.routeChartData.length === 0 ? (
              <p className="py-8 text-center text-muted-foreground">No route data available yet</p>
            ) : (
              <ResponsiveContainer width="100%" height={250}>
                <PieChart>
                  <Pie
                    data={analytics.routeChartData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ route, percent }) => `${route} (${(percent * 100).toFixed(0)}%)`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="amount"
                  >
                    {analytics.routeChartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'hsl(var(--card))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px',
                    }}
                    formatter={(value: number) => [`£${value.toFixed(2)}`, 'Spent']}
                  />
                </PieChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        {/* Insights */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Lightbulb className="h-5 w-5" />
              Insights & Tips
            </CardTitle>
            <CardDescription>Personalized recommendations to optimize your spending</CardDescription>
          </CardHeader>
          <CardContent>
            {insights.length === 0 ? (
              <p className="text-muted-foreground">Start using the app to get personalized insights</p>
            ) : (
              <ul className="space-y-3">
                {insights.map((tip, index) => (
                  <li key={index} className="flex items-start gap-2">
                    <span className="mt-1 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-primary/10 text-xs font-medium text-primary">
                      {index + 1}
                    </span>
                    <span className="text-sm">{tip}</span>
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
