import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import WalletTab from '../components/WalletTab';
import JourneysTab from '../components/JourneysTab';
import AnalyticsTab from '../components/AnalyticsTab';
import RulesTab from '../components/RulesTab';
import CardsTab from '../components/CardsTab';
import SecurityTab from '../components/SecurityTab';

export default function Dashboard() {
  return (
    <div className="container py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground">Manage your transport wallet and track your journeys</p>
      </div>

      <Tabs defaultValue="wallet" className="space-y-6">
        <TabsList className="grid w-full grid-cols-6 lg:w-auto">
          <TabsTrigger value="wallet">Wallet</TabsTrigger>
          <TabsTrigger value="cards">Cards</TabsTrigger>
          <TabsTrigger value="journeys">Journeys</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="rules">Rules</TabsTrigger>
          <TabsTrigger value="security">Security</TabsTrigger>
        </TabsList>

        <TabsContent value="wallet" className="space-y-6">
          <WalletTab />
        </TabsContent>

        <TabsContent value="cards" className="space-y-6">
          <CardsTab />
        </TabsContent>

        <TabsContent value="journeys" className="space-y-6">
          <JourneysTab />
        </TabsContent>

        <TabsContent value="analytics" className="space-y-6">
          <AnalyticsTab />
        </TabsContent>

        <TabsContent value="rules" className="space-y-6">
          <RulesTab />
        </TabsContent>

        <TabsContent value="security" className="space-y-6">
          <SecurityTab />
        </TabsContent>
      </Tabs>
    </div>
  );
}
