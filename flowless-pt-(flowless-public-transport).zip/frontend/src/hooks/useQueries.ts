import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useActor } from './useActor';
import type { UserProfile, Balance, Transaction, Journey, PaymentRule, OysterCard, BankCard } from '../backend';
import { toast } from 'sonner';
import { sanitizeInput } from '../lib/encryption';

export function useGetCallerUserProfile() {
  const { actor, isFetching: actorFetching } = useActor();

  const query = useQuery<UserProfile | null>({
    queryKey: ['currentUserProfile'],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.getCallerUserProfile();
    },
    enabled: !!actor && !actorFetching,
    retry: false,
  });

  return {
    ...query,
    isLoading: actorFetching || query.isLoading,
    isFetched: !!actor && query.isFetched,
  };
}

export function useSaveCallerUserProfile() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (profile: UserProfile) => {
      if (!actor) throw new Error('Actor not available');
      
      // Sanitize inputs before sending to backend
      const sanitizedProfile: UserProfile = {
        name: sanitizeInput(profile.name),
        email: sanitizeInput(profile.email),
        preferences: sanitizeInput(profile.preferences),
      };
      
      return actor.saveCallerUserProfile(sanitizedProfile);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['currentUserProfile'] });
      toast.success('Profile saved successfully');
    },
    onError: (error: Error) => {
      toast.error(`Failed to save profile: ${error.message}`);
    },
  });
}

export function useGetBalance() {
  const { actor, isFetching } = useActor();

  return useQuery<Balance>({
    queryKey: ['balance'],
    queryFn: async () => {
      if (!actor) return { icTokens: BigInt(0), stablecoins: BigInt(0) };
      return actor.getBalance();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useDeposit() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ amount, currency }: { amount: bigint; currency: string }) => {
      if (!actor) throw new Error('Actor not available');
      return actor.deposit(amount, currency);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['balance'] });
      queryClient.invalidateQueries({ queryKey: ['transactions'] });
      toast.success('Deposit successful');
    },
    onError: (error: Error) => {
      toast.error(`Deposit failed: ${error.message}`);
    },
  });
}

export function useWithdraw() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ amount, currency }: { amount: bigint; currency: string }) => {
      if (!actor) throw new Error('Actor not available');
      return actor.withdraw(amount, currency);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['balance'] });
      queryClient.invalidateQueries({ queryKey: ['transactions'] });
      toast.success('Withdrawal successful');
    },
    onError: (error: Error) => {
      toast.error(`Withdrawal failed: ${error.message}`);
    },
  });
}

export function useGetTransactionHistory() {
  const { actor, isFetching } = useActor();

  return useQuery<Transaction[]>({
    queryKey: ['transactions'],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getTransactionHistory();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useGetJourneyHistory() {
  const { actor, isFetching } = useActor();

  return useQuery<Journey[]>({
    queryKey: ['journeys'],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getJourneyHistory();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useAddJourney() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ route, fare }: { route: string; fare: bigint }) => {
      if (!actor) throw new Error('Actor not available');
      return actor.addJourney(sanitizeInput(route), fare);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['journeys'] });
      toast.success('Journey added successfully');
    },
    onError: (error: Error) => {
      toast.error(`Failed to add journey: ${error.message}`);
    },
  });
}

export function useGetPaymentRules() {
  const { actor, isFetching } = useActor();

  return useQuery<PaymentRule[]>({
    queryKey: ['paymentRules'],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getPaymentRules();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useAddPaymentRule() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ condition, action }: { condition: string; action: string }) => {
      if (!actor) throw new Error('Actor not available');
      return actor.addPaymentRule(sanitizeInput(condition), sanitizeInput(action));
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['paymentRules'] });
      toast.success('Payment rule added successfully');
    },
    onError: (error: Error) => {
      toast.error(`Failed to add payment rule: ${error.message}`);
    },
  });
}

// Card Management Hooks

export function useGetOysterCard() {
  const { actor, isFetching } = useActor();

  return useQuery<OysterCard | null>({
    queryKey: ['oysterCard'],
    queryFn: async () => {
      if (!actor) return null;
      return actor.getOysterCard();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useLinkOysterCard() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (cardNumber: string) => {
      if (!actor) throw new Error('Actor not available');
      
      // Sanitize card number (remove any non-digits)
      const sanitizedCardNumber = cardNumber.replace(/\D/g, '');
      
      return actor.linkOysterCard(sanitizedCardNumber);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['oysterCard'] });
      toast.success('Oyster card linked successfully', {
        description: 'Your card data is encrypted and stored securely',
      });
    },
    onError: (error: Error) => {
      toast.error(`Failed to link Oyster card: ${error.message}`);
    },
  });
}

export function useGetLinkedBankCards() {
  const { actor, isFetching } = useActor();

  return useQuery<BankCard[]>({
    queryKey: ['bankCards'],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getLinkedBankCards();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useLinkBankCard() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ cardNumber, holderName, expiry }: { cardNumber: string; holderName: string; expiry: string }) => {
      if (!actor) throw new Error('Actor not available');
      
      // Sanitize inputs before sending to backend
      const sanitizedCardNumber = cardNumber.replace(/\D/g, '');
      const sanitizedHolderName = sanitizeInput(holderName);
      const sanitizedExpiry = expiry.replace(/\D/g, '').slice(0, 4);
      
      // Format expiry as MM/YY
      const formattedExpiry = sanitizedExpiry.length >= 2 
        ? `${sanitizedExpiry.slice(0, 2)}/${sanitizedExpiry.slice(2, 4)}`
        : sanitizedExpiry;
      
      return actor.linkBankCard(sanitizedCardNumber, sanitizedHolderName, formattedExpiry);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['bankCards'] });
      toast.success('Bank card linked successfully', {
        description: 'Your card data is encrypted and stored securely',
      });
    },
    onError: (error: Error) => {
      toast.error(`Failed to link bank card: ${error.message}`);
    },
  });
}

export function useTopUpOysterCard() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ amount, from }: { amount: bigint; from: string }) => {
      if (!actor) throw new Error('Actor not available');
      return actor.topUpOysterCard(amount, sanitizeInput(from));
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['oysterCard'] });
      queryClient.invalidateQueries({ queryKey: ['transactions'] });
      toast.success('Oyster card topped up successfully');
    },
    onError: (error: Error) => {
      toast.error(`Failed to top up Oyster card: ${error.message}`);
    },
  });
}

export function useSetAutoTopUp() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ threshold, fundingSource }: { threshold: bigint; fundingSource: string }) => {
      if (!actor) throw new Error('Actor not available');
      return actor.setAutoTopUp(threshold, sanitizeInput(fundingSource));
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['oysterCard'] });
      toast.success('Auto top-up enabled successfully');
    },
    onError: (error: Error) => {
      toast.error(`Failed to enable auto top-up: ${error.message}`);
    },
  });
}

export function useDisableAutoTopUp() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.disableAutoTopUp();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['oysterCard'] });
      toast.success('Auto top-up disabled successfully');
    },
    onError: (error: Error) => {
      toast.error(`Failed to disable auto top-up: ${error.message}`);
    },
  });
}
