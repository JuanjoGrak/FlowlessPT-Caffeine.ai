/**
 * Encryption utilities for sensitive data
 * 
 * Note: This is a placeholder implementation. True end-to-end encryption
 * requires the backend to handle encryption/decryption with keys stored
 * securely in the canister. Client-side encryption alone cannot provide
 * the security guarantees needed for PCI DSS and GDPR compliance.
 * 
 * The backend must implement:
 * - Secure key generation and storage within the canister
 * - AES-256 encryption for sensitive fields before storage
 * - Decryption only for authorized callers at query time
 * - Key rotation policies
 * - Audit logging
 */

/**
 * Masks sensitive card numbers for display
 * Shows only the last 4 digits
 */
export function maskCardNumber(cardNumber: string): string {
  if (cardNumber.length < 4) return cardNumber;
  return '•••• •••• •••• ' + cardNumber.slice(-4);
}

/**
 * Validates card number format (basic Luhn algorithm check)
 */
export function validateCardNumber(cardNumber: string): boolean {
  const cleaned = cardNumber.replace(/\D/g, '');
  if (cleaned.length < 13 || cleaned.length > 19) return false;

  let sum = 0;
  let isEven = false;

  for (let i = cleaned.length - 1; i >= 0; i--) {
    let digit = parseInt(cleaned[i], 10);

    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    isEven = !isEven;
  }

  return sum % 10 === 0;
}

/**
 * Validates expiry date format (MM/YY)
 */
export function validateExpiryDate(expiry: string): boolean {
  const match = expiry.match(/^(0[1-9]|1[0-2])\/([0-9]{2})$/);
  if (!match) return false;

  const month = parseInt(match[1], 10);
  const year = parseInt('20' + match[2], 10);
  const now = new Date();
  const expiryDate = new Date(year, month - 1);

  return expiryDate > now;
}

/**
 * Sanitizes user input to prevent injection attacks
 */
export function sanitizeInput(input: string): string {
  return input.trim().replace(/[<>]/g, '');
}

/**
 * Formats card number with spaces for display (before masking)
 */
export function formatCardNumberDisplay(cardNumber: string): string {
  const cleaned = cardNumber.replace(/\D/g, '');
  const groups = cleaned.match(/.{1,4}/g);
  return groups ? groups.join(' ') : cleaned;
}

/**
 * Generates a secure random identifier for client-side tracking
 */
export function generateSecureId(): string {
  const array = new Uint8Array(16);
  crypto.getRandomValues(array);
  return Array.from(array, byte => byte.toString(16).padStart(2, '0')).join('');
}
