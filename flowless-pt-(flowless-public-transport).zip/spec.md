# Flowless PT (Flowless Public Transport)

## Overview
Flowless PT (Flowless Public Transport) is a decentralized application that manages public transport payments and provides DeFi analytics for transport-related expenses. The system uses multiple specialized canisters to handle secure fund storage, automated payments, transport network integration, and card management including Oyster cards and bank cards with comprehensive end-to-end encryption for all sensitive data.

## Core Features

### Wallet Management
- Users can deposit IC tokens and stablecoins into their secure vault
- View current balance and transaction history
- Withdraw funds when needed
- Set spending limits and payment preferences

### Card Management
- Link and manage Oyster cards with real-time balance tracking
- Link multiple bank cards for funding transport payments
- Top up Oyster cards using bank cards or main wallet balance
- Automatic Oyster card top-up when balance falls below configurable threshold
- View masked card numbers and card details for security

### Journey Tracking
- Track public transport journeys with fare calculations
- View journey history with dates, routes, and costs
- Display real-time fare pricing from transport networks
- Journey validation through transport API integration

### Automated Payments
- Automatic fare payment when using public transport
- Batch transaction processing for cost efficiency
- Conditional payment execution based on user-defined rules
- Payment authorization and confirmation system
- Automated Oyster card top-up based on user preferences

### DeFi Analytics
- Cost analysis and spending patterns for transport expenses including Oyster top-ups
- Optimization suggestions for transport costs
- Monthly and yearly spending reports including card refills
- Budget tracking and alerts

## Security and Encryption

### End-to-End Encryption
- All sensitive user and financial data is encrypted using AES-256 symmetric encryption
- Encrypted fields include bank card numbers, expiry dates, holder names, Oyster card numbers, user profiles, wallet balances, user preferences, and transaction records
- Only ciphertext is stored in the backend; decryption occurs at query time for authorized callers
- Encryption keys are generated securely within canisters and stored in canister memory, never exposed to clients or logged
- All API calls use automatic encryption for inbound and outbound data with secure HTTPS transport
- Transport-layer encryption ensures payloads are encrypted before transmission and decrypted only after authenticated access
- No plain text storage or logging of sensitive data anywhere in the system

### Data Protection Compliance
- Full compliance with EU GDPR principles including data minimization, confidentiality, and integrity
- PCI DSS compliance for payment card data handling
- Secure key management and rotation policies
- Data access logging and audit trails
- Compliance documentation and indicators displayed in app's security and profile setup sections
- GDPR and PCI DSS alignment confirmations visible to users within the application

## Backend Architecture

### Vault Canister
- Stores user funds securely (IC tokens, stablecoins) with encrypted balances
- Manages deposits and withdrawals with encrypted transaction records
- Handles payment authorization to transport networks
- Maintains encrypted user balance and transaction records
- Stores encrypted linked Oyster card and bank card information
- Manages Oyster card top-up operations and automatic refill logic
- Implements AES-256 encryption for all sensitive data fields
- Encrypts user profiles and personal information

### Relayer Canister
- Processes automated transport fare payments with encrypted data handling
- Batches multiple transactions for efficiency
- Communicates with external transport partners using encrypted channels
- Manages payment queues and retry logic with encrypted payment data
- Ensures no plain text data in processing or logs

### Executor Canister
- Runs programmable tasks for cost optimization with encrypted user preferences
- Executes conditional fare payments based on encrypted user rules
- Handles scheduled payments and recurring transactions
- Manages encrypted user-defined automation rules
- Executes automatic Oyster card top-ups when thresholds are met
- Maintains encrypted audit logs for all operations

### TfL Proxy Canister
- Simulates Transport for London API integration
- Provides journey validation services
- Returns fare pricing information
- Handles route planning and transport data
- Encrypts any user-specific journey data

## Data Storage

### Backend Data
- Encrypted user account information, profiles, and preferences
- Encrypted fund balances and transaction history
- Journey records with fare details (encrypted where user-specific)
- Encrypted payment rules and automation settings
- Transport network integration data
- Mock transport data for simulation
- Encrypted linked Oyster card details and balances
- Encrypted linked bank card information (masked card numbers)
- Encrypted auto top-up preferences and thresholds
- All sensitive data stored only in encrypted form with no plain text logs

### Frontend Data
- Current session state
- Real-time journey tracking
- Dashboard display preferences
- Temporary form data (encrypted before transmission)
- Card management interface state
- Client-side encryption for sensitive user input before API calls
- Compliance status indicators and documentation access

## Mock Data Integration
- Sample user accounts with encrypted transaction history
- Mock transport routes and fare structures
- Simulated API responses from transport networks
- Test payment scenarios and edge cases
- Sample encrypted Oyster card and bank card data

## System Expandability
- Modular canister architecture for adding new transport systems
- Standardized encrypted API interfaces for transport network integration
- Configurable payment rules engine with encrypted rule storage
- Extensible analytics and reporting framework
- Expandable card management system for additional card types

## Application Branding
- Application name displayed as "Flowless PT (Flowless Public Transport)" throughout the frontend
- English language content across all user interfaces
- Consistent branding in headers, titles, and landing pages

## Compliance and Security Features
- Security section in user profile displaying encryption status and compliance indicators
- Profile setup sections showing GDPR and PCI DSS alignment confirmations
- Audit trail access for users to view their data handling compliance
- Security settings allowing users to verify encryption status of their data
